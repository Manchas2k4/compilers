package nodes;

import errors.*;

public interface Node {
}
