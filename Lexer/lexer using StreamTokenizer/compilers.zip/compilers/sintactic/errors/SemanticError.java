package errors;

public class SemanticError extends Exception {
	public SemanticError() {
		super();
	}
	
	public SemanticError(String s) {
		super(s);
	}
}
